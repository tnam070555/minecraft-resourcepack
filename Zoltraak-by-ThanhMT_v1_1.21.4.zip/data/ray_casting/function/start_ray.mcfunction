summon marker ~ ~ ~ {Tags:["beam"]}
tag @s add facing_ray
execute as @e[tag=beam] at @s run execute rotated as @e[tag=facing_ray] run tp @s ~ ~ ~ ~ ~
tag @e remove facing_ray

execute if score #destroy destroy_block matches 0 run execute as @e[tag=beam] at @s run function ray_casting:ray_disable
execute as @e[tag=beam] at @s run function ray_casting:ray