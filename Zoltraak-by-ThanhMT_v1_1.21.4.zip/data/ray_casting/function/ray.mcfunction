scoreboard players add @s block_step 1
execute as @s at @s run particle glow ~ ~ ~ 1 1 1 0.3 5 force
execute as @s at @s run particle dust_color_transition{from_color:[0.098,0.000,1.000],scale:2,to_color:[0.565,0.000,1.000]} ~ ~ ~ 1 1 1 1 3 force
#execute as @s at @s run particle reverse_portal ~ ~ ~ 0.3 0.3 0.3 0.3 2 force
execute as @s at @s run tp @s ^ ^ ^0.5

execute at @s as @e[distance=..3.5,tag=!destroy_tnt,tag=!facing_ray] run damage @s 50 magic

#execute as @s at @s run execute unless block ~ ~ ~ air run particle explosion ~ ~ ~ 1 1 1 1 5 force
execute as @s at @s run execute unless block ~ ~ ~ air run particle end_rod ~ ~ ~ 1 1 1 1 3 force
execute as @s at @s run execute unless block ~ ~ ~ air run particle minecraft:trial_spawner_detection_ominous ~ ~ ~ 1 1 1 1 3 force
execute as @s at @s run execute unless block ~ ~ ~ air run summon tnt ~ ~ ~ {fuse:0,explosion_power:2,Tags:["destroy_tnt"]}
execute if score @s block_step matches 251.. run return run kill @s
execute if score @s block_step matches ..250 run function ray_casting:ray