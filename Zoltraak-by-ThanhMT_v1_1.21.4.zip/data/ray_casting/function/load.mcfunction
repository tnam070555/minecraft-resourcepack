schedule function ray_casting:tick_1s 1s
scoreboard objectives add block_step dummy
scoreboard objectives add destroy_block dummy

scoreboard players add #init destroy_block 1
execute if score #init destroy_block matches 1 run scoreboard players set #destroy destroy_block 1

execute if score #destroy destroy_block matches 0..1 run tellraw @p [{"color":"aqua","text":"[Zoltraak - By ThanhMT]"},{"color":"dark_blue","hoverEvent":{"action":"show_text","value":[{"text":"","color":"yellow"}]},"text":" : đã được cài đặt"}]
execute if score #destroy destroy_block matches 0..1 run tellraw @p {"color":"gold","text":"==========Tùy chọn=========="}
execute if score #destroy destroy_block matches 1 run tellraw @p [{"color":"yellow","text":"Phá khối: "},{"clickEvent":{"action":"run_command","value":"/function ray_casting:on_off {score:'1'}"},"color":"green","hoverEvent":{"action":"show_text","value":[{"text":"zoltraak có thể phá được khối"}]},"text":"[Bật]"},{"clickEvent":{"action":"run_command","value":"/function ray_casting:on_off {score:'0'}"},"color":"red","hoverEvent":{"action":"show_text","value":[{"text":"Zoltraak không thể phá khối"}]},"text":"[Tắt]"}]
execute if score #destroy destroy_block matches 0 run tellraw @p [{"color":"yellow","text":"Phá khối: "},{"clickEvent":{"action":"run_command","value":"/function ray_casting:on_off {score:'1'}"},"color":"red","hoverEvent":{"action":"show_text","value":[{"text":"zoltraak có thể phá được khối"}]},"text":"[Bật]"},{"clickEvent":{"action":"run_command","value":"/function ray_casting:on_off {score:'0'}"},"color":"green","hoverEvent":{"action":"show_text","value":[{"text":"Zoltraak không thể phá khối"}]},"text":"[Tắt]"}]