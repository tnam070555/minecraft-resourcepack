scoreboard objectives add block_step dummy
scoreboard objectives add destroy_block dummy

scoreboard players add #init destroy_block 1
execute if score #init destroy_block matches 1 run scoreboard players set #destroy destroy_block 1
execute if score #destroy destroy_block matches 1 run reload