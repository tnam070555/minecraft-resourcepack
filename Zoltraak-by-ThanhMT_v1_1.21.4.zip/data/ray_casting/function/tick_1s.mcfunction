execute unless entity @e[tag=aj.zoltraak_circle.root] run kill @e[tag=aj.zoltraak_circle.node]
schedule function ray_casting:tick_1s 1s