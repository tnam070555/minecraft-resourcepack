advancement revoke @s from staff:using_wand

execute store result score #this timestamp run time query gametime
scoreboard players add @s timestamp 1

execute unless score @s timestamp = #this timestamp run function trail:zoltraak

scoreboard players operation @s timestamp = #this timestamp