$particle trail{color:[1.000,1.000,1.000],target:[$(end_x),$(end_y),$(end_z)],duration:10} ^ ^ ^ 0.3 0.3 0.3 1 30 force
$particle trail{color:[0.090,0.212,1.000],target:[$(end_x),$(end_y),$(end_z)],duration:10} ^ ^ ^ 0.3 0.3 0.3 1 30 force
$particle trail{color:[0.090,0.424,1.000],target:[$(end_x),$(end_y),$(end_z)],duration:10} ^ ^ ^ 0.3 0.3 0.3 1 30 force