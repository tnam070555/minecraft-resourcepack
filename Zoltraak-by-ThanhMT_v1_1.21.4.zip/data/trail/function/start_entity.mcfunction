$execute as @e[tag=$(point2),limit=1,sort=nearest] at @s run execute store result storage trail end_x float 1.0001 run data get entity @s Pos[0]
$execute as @e[tag=$(point2),limit=1,sort=nearest] at @s run execute store result storage trail end_y float 1.0001 run data get entity @s Pos[1]
$execute as @e[tag=$(point2),limit=1,sort=nearest] at @s run execute store result storage trail end_z float 1.0001 run data get entity @s Pos[2]


function trail:run_particle with storage minecraft:trail